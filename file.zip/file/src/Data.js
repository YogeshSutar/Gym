export const data = [
    {Name: "Mahesh",age: 23,salary: 23000,Location: "Pune"},
    {Name: "Yohesh",age: 29,salary: 3400,Location: "Mumbai"},
    {Name: "Krishna",age: 27,salary: 2100,Location: "Pimpri"},
    {Name: "Komal",age: 21,salary: 230,Location: "indapur"},
    {Name: "Vishal",age: 20,salary: 20000,Location: "kolhapur"},
]