export const contentimage = [
    {content: "Mahesh",image: ''}
]