import '../Styles/ContentImageRight.css'
const ContentImageRight=()=>{
    return(
        <>
        <div className="container">
            <div className="leftContent">
                <h1>Make Yourself Stronger
                than your best excuses</h1>
                <p>Fitness Gym is where I go to work out. It is the best gym of all for me. The equipment is new and well organized to help you train most effectively, The gym has exercise bikes and running machines. While some guests play golf, others work out in the hotel gym. </p>

            </div>
            <div className='rightImage'>
                
                <img src=""/>
            </div>
        </div>
        </>
    )
}

export default ContentImageRight