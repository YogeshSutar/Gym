import Navbar from '../Components/Navbar.jsx'

const AboutUs = ()=>{
    return(
        <>
        <Navbar/>
        <h1>
            About Us Page
        </h1>
        </>
    )
}

export default AboutUs