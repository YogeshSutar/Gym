import Navbar from '../Components/Navbar.jsx'

const Dashboard = () =>{
    return(
        <>
        <Navbar/>
        <h1>
            Dashboard Page
        </h1>
        </>
    )
}

export default Dashboard