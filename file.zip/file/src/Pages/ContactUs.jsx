import Navbar from '../Components/Navbar.jsx'

const ContactUs = ()=>{
    return (
        <>
        <Navbar/>
        <h1>Contact Us</h1>
        </>
    )
}

export default ContactUs